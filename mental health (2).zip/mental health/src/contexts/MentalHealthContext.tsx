import React, { createContext, useContext, useState, useEffect } from 'react';

// Mental health conditions configuration
export const CONDITIONS = {
  stress: {
    id: 'stress',
    name: 'Stress Management',
    emoji: '🌊',
    color: 'stress',
    description: 'Managing stress and finding balance in daily life.',
    features: {
      primary: 'Stress Level Tracking',
      secondary: ['Trigger Identification', 'Relaxation Techniques', 'Work-Life Balance']
    },
    metrics: ['stress_level', 'triggers', 'relaxation_time', 'work_hours'],
    tips: [
      'Take 5 deep breaths when feeling overwhelmed. Breathe in for 4, hold for 4, out for 6.',
      'Try the 5-4-3-2-1 grounding technique: 5 things you see, 4 you touch, 3 you hear, 2 you smell, 1 you taste.',
      'Take a 10-minute walk outside. Fresh air and movement can reset your stress response.',
      'Practice progressive muscle relaxation: tense and release each muscle group for 5 seconds.',
      'Set boundaries between work and personal time. Turn off notifications after work hours.',
      'Keep a stress trigger journal to identify patterns and prepare coping strategies.',
    ],
    exercises: [
      'Complete a 10-minute meditation',
      'Take 3 deep breathing breaks',
      'Go for a walk in nature',
      'Write in a gratitude journal',
      'Do light stretching or yoga',
      'Practice progressive muscle relaxation',
      'Try box breathing (4-4-4-4 pattern)',
      'Listen to calming music for 15 minutes',
    ],
    techniques: [
      { name: 'Box Breathing', duration: '5 min', description: 'Inhale 4, hold 4, exhale 4, hold 4' },
      { name: 'Progressive Muscle Relaxation', duration: '15 min', description: 'Tense and release each muscle group' },
      { name: '5-4-3-2-1 Grounding', duration: '3 min', description: 'Engage all five senses to ground yourself' },
      { name: 'Mindful Walking', duration: '10 min', description: 'Focus on each step and breath' },
    ]
  },
  depression: {
    id: 'depression',
    name: 'Depression Support',
    emoji: '🌱',
    color: 'depression',
    description: 'Building resilience and finding hope through difficult times.',
    features: {
      primary: 'Energy & Mood Tracking',
      secondary: ['Social Connection', 'Activity Enjoyment', 'Self-Care Goals']
    },
    metrics: ['energy_level', 'social_connections', 'activity_enjoyment', 'self_care_tasks'],
    tips: [
      'Start your day with one small accomplishment, even if it\'s just making your bed.',
      'Reach out to one person today - a text, call, or brief conversation can help.',
      'Practice self-compassion: treat yourself with the same kindness you\'d show a good friend.',
      'Engage in an activity that used to bring you joy, even if it doesn\'t feel the same right now.',
      'Set tiny, achievable goals. Progress is progress, no matter how small.',
      'Celebrate small wins - they\'re building blocks to bigger victories.',
    ],
    exercises: [
      'Complete one small daily task',
      'Connect with a friend or family member',
      'Practice 5 minutes of self-compassion',
      'Engage in a creative activity',
      'Spend time in sunlight',
      'Write down 3 things you\'re grateful for',
      'Take a warm shower or bath',
      'Listen to uplifting music',
    ],
    selfCareChecklist: [
      { task: 'Take a shower', category: 'hygiene' },
      { task: 'Eat a nutritious meal', category: 'nutrition' },
      { task: 'Get some sunlight', category: 'physical' },
      { task: 'Connect with someone', category: 'social' },
      { task: 'Do something creative', category: 'mental' },
      { task: 'Practice gratitude', category: 'emotional' },
    ]
  },
  insomnia: {
    id: 'insomnia',
    name: 'Sleep Center',
    emoji: '🌙',
    color: 'insomnia',
    description: 'Improving sleep quality and establishing healthy sleep patterns.',
    features: {
      primary: 'Sleep Schedule Tracking',
      secondary: ['Sleep Hygiene', 'Environment Optimization', 'Sleep Debt Monitoring']
    },
    metrics: ['bedtime', 'wake_time', 'sleep_quality', 'sleep_duration', 'sleep_debt'],
    tips: [
      'Create a bedtime routine: same time each night, dim lights 1 hour before bed.',
      'Try the 4-7-8 breathing technique: inhale 4, hold 7, exhale 8. Repeat 4 times.',
      'Keep your bedroom cool (65-68°F), dark, and quiet for optimal sleep.',
      'If you can\'t sleep after 20 minutes, get up and do a quiet activity until sleepy.',
      'Avoid caffeine 6 hours before bedtime and large meals 3 hours before.',
      'Get morning sunlight to regulate your circadian rhythm.',
    ],
    exercises: [
      'Follow a consistent bedtime routine',
      'Practice relaxation breathing',
      'Avoid screens 1 hour before bed',
      'Create a sleep-friendly environment',
      'Try gentle bedtime stretches',
      'Write in a sleep journal',
      'Practice body scan meditation',
      'Use progressive muscle relaxation',
    ],
    sleepHygiene: [
      { item: 'No screens 1 hour before bed', category: 'technology' },
      { item: 'Keep bedroom cool (65-68°F)', category: 'environment' },
      { item: 'Use blackout curtains', category: 'environment' },
      { item: 'No caffeine after 2 PM', category: 'diet' },
      { item: 'Regular bedtime routine', category: 'routine' },
      { item: 'Comfortable mattress & pillows', category: 'comfort' },
    ]
  },
  adhd: {
    id: 'adhd',
    name: 'ADHD Focus Hub',
    emoji: '🧠',
    color: 'adhd',
    description: 'Enhancing focus, organization, and executive function skills.',
    features: {
      primary: 'Focus Session Timer',
      secondary: ['Task Breakdown', 'Distraction Tracking', 'Organization Challenges']
    },
    metrics: ['focus_sessions', 'task_completion', 'distractions', 'organization_score'],
    tips: [
      'Break large tasks into 15-minute focused chunks. Use a timer to stay on track.',
      'Create external reminders: sticky notes, phone alarms, or visual cues for important tasks.',
      'Use the "two-minute rule": if something takes less than 2 minutes, do it immediately.',
      'Find your optimal focus time and schedule important work during these periods.',
      'Use fidget tools or background music to help maintain focus during tasks.',
      'Reward yourself after completing focused work sessions.',
    ],
    exercises: [
      'Complete a 15-minute focused work session',
      'Organize one small area',
      'Use a timer for tasks',
      'Practice mindfulness for 5 minutes',
      'Create tomorrow\'s priority list',
      'Break down one large task into smaller steps',
      'Try the Pomodoro Technique',
      'Practice deep breathing for focus',
    ],
    focusIntervals: [
      { name: 'Quick Focus', duration: 15, description: 'Short burst for easy tasks' },
      { name: 'Standard Focus', duration: 25, description: 'Pomodoro-style focus session' },
      { name: 'Deep Focus', duration: 45, description: 'For complex projects' },
      { name: 'Hyperfocus Safe', duration: 90, description: 'Productive hyperfocus with breaks' },
    ]
  },
  ocd: {
    id: 'ocd',
    name: 'OCD Management Center',
    emoji: '🔄',
    color: 'ocd',
    description: 'Managing obsessive thoughts and compulsive behaviors with mindfulness.',
    features: {
      primary: 'Compulsion Delay Timer',
      secondary: ['Ritual Tracking', 'Exposure Therapy', 'Thought Challenging']
    },
    metrics: ['compulsion_frequency', 'delay_time', 'exposure_progress', 'anxiety_levels'],
    tips: [
      'Practice "noting" thoughts: "I\'m having the thought that..." to create distance from obsessions.',
      'Delay compulsions by 5 minutes, then 10, gradually increasing the delay time.',
      'Use exposure and response prevention: face fears in small, manageable steps.',
      'Remember: thoughts are not facts, and having a thought doesn\'t make it true or important.',
      'Practice uncertainty tolerance: "I can handle not knowing for sure."',
      'Use mindfulness to observe thoughts without engaging with them.',
    ],
    exercises: [
      'Practice thought noting for 10 minutes',
      'Delay a compulsion by 5 minutes',
      'Complete a mindfulness exercise',
      'Face a small fear step',
      'Practice acceptance meditation',
      'Do an exposure therapy exercise',
      'Challenge an obsessive thought',
      'Practice uncertainty meditation',
    ],
    exposureSteps: [
      { level: 'Easy', anxiety: '2-3', description: 'Minimal discomfort' },
      { level: 'Moderate', anxiety: '4-6', description: 'Noticeable but manageable' },
      { level: 'Challenging', anxiety: '7-8', description: 'High anxiety but doable' },
      { level: 'Advanced', anxiety: '9-10', description: 'Very difficult exposure' },
    ]
  },
  anxiety: {
    id: 'anxiety',
    name: 'Anxiety Relief Station',
    emoji: '🦋',
    color: 'anxiety',
    description: 'Calming anxious thoughts and building confidence in uncertainty.',
    features: {
      primary: 'Panic Attack Tracker',
      secondary: ['Worry Time', 'Social Anxiety Challenges', 'Physical Symptoms']
    },
    metrics: ['panic_attacks', 'worry_time', 'social_exposure', 'physical_symptoms'],
    tips: [
      'Challenge anxious thoughts: "Is this thought helpful? Is it likely? What would I tell a friend?"',
      'Use box breathing: inhale 4, hold 4, exhale 4, hold 4. Repeat 4-6 times.',
      'Practice the STOP technique: Stop, Take a breath, Observe, Proceed mindfully.',
      'Create a "worry window": dedicate 15 minutes daily to worry, then redirect anxious thoughts.',
      'Use the 54321 technique: 5 things you see, 4 you hear, 3 you feel, 2 you smell, 1 you taste.',
      'Practice self-compassion when anxiety arises - it\'s a normal human experience.',
    ],
    exercises: [
      'Practice box breathing for 5 minutes',
      'Challenge 3 anxious thoughts',
      'Complete a grounding exercise',
      'Use progressive muscle relaxation',
      'Write in an anxiety journal',
      'Do a worry time session',
      'Practice a social exposure',
      'Try butterfly breathing technique',
    ],
    copingStrategies: [
      { name: 'Box Breathing', type: 'immediate', effectiveness: 'high' },
      { name: '54321 Grounding', type: 'immediate', effectiveness: 'high' },
      { name: 'Thought Challenging', type: 'cognitive', effectiveness: 'medium' },
      { name: 'Progressive Muscle Relaxation', type: 'physical', effectiveness: 'high' },
    ]
  },
};

// Enhanced types for our context
interface MoodEntry {
  date: string;
  mood: number;
  condition: string;
  notes?: string;
  // Condition-specific data
  energy_level?: number;
  stress_level?: number;
  sleep_quality?: number;
  focus_rating?: number;
  anxiety_level?: number;
  compulsion_urges?: number;
}

interface ActivityProgress {
  condition: string;
  completedExercises: string[];
  totalSessions: number;
  lastActiveDate: string;
  // Condition-specific tracking
  conditionData?: {
    // Stress
    stressTriggers?: string[];
    relaxationMinutes?: number;
    workLifeBalance?: number;
    
    // Depression  
    energyLevels?: number[];
    socialConnections?: number;
    selfCareCompleted?: string[];
    
    // Insomnia
    sleepSchedule?: { bedtime: string; wakeTime: string }[];
    sleepDebt?: number;
    sleepHygieneScore?: number;
    
    // ADHD
    focusSessions?: { duration: number; completed: boolean; date: string }[];
    distractions?: string[];
    organizationTasks?: string[];
    
    // OCD
    compulsionDelays?: { planned: number; actual: number }[];
    exposureProgress?: { level: string; anxiety: number; date: string }[];
    ritualFrequency?: number[];
    
    // Anxiety
    panicAttacks?: { duration: number; triggers: string[]; date: string }[];
    worryTimeUsed?: number[];
    socialExposures?: string[];
  };
}

interface MentalHealthContextType {
  currentCondition: string | null;
  setCurrentCondition: (condition: string | null) => void;
  moodEntries: MoodEntry[];
  addMoodEntry: (entry: Omit<MoodEntry, 'date'>) => void;
  activityProgress: Record<string, ActivityProgress>;
  completeExercise: (condition: string, exercise: string) => void;
  getCurrentTipIndex: (condition: string) => number;
  incrementTipIndex: (condition: string) => void;
  resetProgress: () => void;
}

const MentalHealthContext = createContext<MentalHealthContextType | undefined>(undefined);

export const MentalHealthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentCondition, setCurrentCondition] = useState<string | null>(null);
  const [moodEntries, setMoodEntries] = useState<MoodEntry[]>([]);
  const [activityProgress, setActivityProgress] = useState<Record<string, ActivityProgress>>({});
  const [tipIndices, setTipIndices] = useState<Record<string, number>>({});

  // Load data from localStorage on mount
  useEffect(() => {
    const savedMoodEntries = localStorage.getItem('mentalHealthMoodEntries');
    const savedProgress = localStorage.getItem('mentalHealthProgress');
    const savedTipIndices = localStorage.getItem('mentalHealthTipIndices');

    if (savedMoodEntries) {
      setMoodEntries(JSON.parse(savedMoodEntries));
    }
    if (savedProgress) {
      setActivityProgress(JSON.parse(savedProgress));
    }
    if (savedTipIndices) {
      setTipIndices(JSON.parse(savedTipIndices));
    }
  }, []);

  // Save data to localStorage whenever state changes
  useEffect(() => {
    localStorage.setItem('mentalHealthMoodEntries', JSON.stringify(moodEntries));
  }, [moodEntries]);

  useEffect(() => {
    localStorage.setItem('mentalHealthProgress', JSON.stringify(activityProgress));
  }, [activityProgress]);

  useEffect(() => {
    localStorage.setItem('mentalHealthTipIndices', JSON.stringify(tipIndices));
  }, [tipIndices]);

  const addMoodEntry = (entry: Omit<MoodEntry, 'date'>) => {
    const newEntry: MoodEntry = {
      ...entry,
      date: new Date().toISOString(),
    };
    setMoodEntries(prev => [newEntry, ...prev].slice(0, 30)); // Keep last 30 entries
  };

  const completeExercise = (condition: string, exercise: string) => {
    setActivityProgress(prev => {
      const existing = prev[condition] || {
        condition,
        completedExercises: [],
        totalSessions: 0,
        lastActiveDate: new Date().toISOString(),
      };

      const updatedExercises = existing.completedExercises.includes(exercise)
        ? existing.completedExercises
        : [...existing.completedExercises, exercise];

      return {
        ...prev,
        [condition]: {
          ...existing,
          completedExercises: updatedExercises,
          totalSessions: existing.totalSessions + (existing.completedExercises.includes(exercise) ? 0 : 1),
          lastActiveDate: new Date().toISOString(),
        },
      };
    });
  };

  const getCurrentTipIndex = (condition: string): number => {
    return tipIndices[condition] || 0;
  };

  const incrementTipIndex = (condition: string) => {
    setTipIndices(prev => {
      const currentIndex = prev[condition] || 0;
      const maxIndex = CONDITIONS[condition as keyof typeof CONDITIONS]?.tips.length || 0;
      return {
        ...prev,
        [condition]: (currentIndex + 1) % maxIndex,
      };
    });
  };

  const resetProgress = () => {
    localStorage.removeItem('mentalHealthMoodEntries');
    localStorage.removeItem('mentalHealthProgress');
    localStorage.removeItem('mentalHealthTipIndices');
    setMoodEntries([]);
    setActivityProgress({});
    setTipIndices({});
  };

  const value: MentalHealthContextType = {
    currentCondition,
    setCurrentCondition,
    moodEntries,
    addMoodEntry,
    activityProgress,
    completeExercise,
    getCurrentTipIndex,
    incrementTipIndex,
    resetProgress,
  };

  return (
    <MentalHealthContext.Provider value={value}>
      {children}
    </MentalHealthContext.Provider>
  );
};

export const useMentalHealth = () => {
  const context = useContext(MentalHealthContext);
  if (context === undefined) {
    throw new Error('useMentalHealth must be used within a MentalHealthProvider');
  }
  return context;
};