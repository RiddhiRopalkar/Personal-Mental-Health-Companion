import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  ArrowLeft, 
  Lightbulb, 
  TrendingUp, 
  CheckCircle2, 
  Circle,
  Phone,
  BarChart3,
  Heart,
  Sparkles
} from 'lucide-react';
import { CONDITIONS, useMentalHealth } from '@/contexts/MentalHealthContext';
import { useToast } from '@/hooks/use-toast';

interface MoodChartProps {
  entries: Array<{ date: string; mood: number; condition: string }>;
  condition: string;
}

const MoodChart: React.FC<MoodChartProps> = ({ entries, condition }) => {
  const conditionEntries = entries
    .filter(entry => entry.condition === condition)
    .slice(0, 7)
    .reverse();

  if (conditionEntries.length === 0) {
    return (
      <div className="text-center text-muted-foreground py-8">
        <BarChart3 className="w-12 h-12 mx-auto mb-4 opacity-50" />
        <p>Start logging your mood to see progress here!</p>
      </div>
    );
  }

  const maxMood = Math.max(...conditionEntries.map(e => e.mood));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between text-sm text-muted-foreground">
        <span>Last 7 entries</span>
        <span>Mood Scale 1-10</span>
      </div>
      
      <div className="flex items-end space-x-2 h-32">
        {conditionEntries.map((entry, index) => {
          const height = (entry.mood / 10) * 100;
          const date = new Date(entry.date).toLocaleDateString('en-US', { 
            month: 'short', 
            day: 'numeric' 
          });
          
          return (
            <div key={index} className="flex-1 flex flex-col items-center">
              <div 
                className={`w-full bg-gradient-success rounded-t opacity-80 transition-all duration-500`}
                style={{ height: `${height}%` }}
              />
              <div className="mt-2 text-xs text-muted-foreground text-center">
                <div className="font-medium">{entry.mood}</div>
                <div>{date}</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const ConditionPage = () => {
  const { conditionId } = useParams<{ conditionId: string }>();
  const { toast } = useToast();
  const {
    moodEntries,
    addMoodEntry,
    activityProgress,
    completeExercise,
    getCurrentTipIndex,
    incrementTipIndex,
  } = useMentalHealth();

  const [currentMood, setCurrentMood] = useState([7]);
  const [showCrisisResources, setShowCrisisResources] = useState(false);

  const condition = conditionId ? CONDITIONS[conditionId as keyof typeof CONDITIONS] : null;

  useEffect(() => {
    if (condition) {
      document.title = `${condition.name} Support - MindCare`;
    }
  }, [condition]);

  if (!condition) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Condition Not Found</h1>
          <Link to="/">
            <Button>Return Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  const currentTipIndex = getCurrentTipIndex(condition.id);
  const currentTip = condition.tips[currentTipIndex];
  const progress = activityProgress[condition.id];
  const completedExercises = progress?.completedExercises || [];
  const completionPercentage = (completedExercises.length / condition.exercises.length) * 100;

  const handleMoodLog = () => {
    addMoodEntry({
      mood: currentMood[0],
      condition: condition.id,
      notes: `Mood logged for ${condition.name}`,
    });
    
    toast({
      title: "Mood Logged! 📊",
      description: `Your mood of ${currentMood[0]}/10 has been recorded.`,
    });
  };

  const handleExerciseComplete = (exercise: string) => {
    const isCompleted = completedExercises.includes(exercise);
    
    if (!isCompleted) {
      completeExercise(condition.id, exercise);
      toast({
        title: "Great Job! ✨",
        description: `You completed: ${exercise}`,
      });
    }
  };

  const handleGetNextTip = () => {
    incrementTipIndex(condition.id);
    toast({
      title: "New Tip! 💡",
      description: "Here's another helpful suggestion for you.",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-background">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link to="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Home
                </Button>
              </Link>
              <div className="flex items-center space-x-3">
                <div className="text-3xl">{condition.emoji}</div>
                <div>
                  <h1 className="text-xl font-bold text-foreground">{condition.name} Support</h1>
                  <p className="text-sm text-muted-foreground">Personalized guidance and tracking</p>
                </div>
              </div>
            </div>
            
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowCrisisResources(!showCrisisResources)}
              className="bg-destructive/10 text-destructive border-destructive/20 hover:bg-destructive hover:text-destructive-foreground"
            >
              <Phone className="w-4 h-4 mr-2" />
              Crisis Help
            </Button>
          </div>
        </div>
      </header>

      {/* Crisis Resources Modal */}
      {showCrisisResources && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md">
            <CardHeader className="text-center">
              <CardTitle className="text-destructive">Crisis Resources</CardTitle>
              <CardDescription>Immediate help is available 24/7</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h4 className="font-semibold">National Suicide Prevention Lifeline</h4>
                <p className="text-lg font-mono">988</p>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold">Crisis Text Line</h4>
                <p>Text <span className="font-mono">HOME</span> to <span className="font-mono">741741</span></p>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold">International</h4>
                <p className="text-sm text-muted-foreground">Visit befrienders.org for local resources</p>
              </div>
              <Button 
                onClick={() => setShowCrisisResources(false)}
                className="w-full"
              >
                Close
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Overview */}
            <Card className="bg-gradient-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Heart className="w-5 h-5 text-primary" />
                  <span>About {condition.name}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-lg">{condition.description}</p>
              </CardContent>
            </Card>

            {/* AI Tips */}
            <Card className="bg-gradient-card">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Lightbulb className="w-5 h-5 text-warning" />
                    <span>AI-Powered Guidance</span>
                  </div>
                  <Badge variant="secondary" className="bg-warning/20 text-warning">
                    Tip {currentTipIndex + 1} of {condition.tips.length}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-warning/5 p-4 rounded-lg border-l-4 border-warning">
                  <p className="text-foreground leading-relaxed">{currentTip}</p>
                </div>
                <Button onClick={handleGetNextTip} variant="outline" className="w-full">
                  <Sparkles className="w-4 h-4 mr-2" />
                  Get Another Tip
                </Button>
              </CardContent>
            </Card>

            {/* Daily Exercises */}
            <Card className="bg-gradient-card">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-5 h-5 text-success" />
                    <span>Daily Exercises</span>
                  </div>
                  <Badge variant="secondary" className="bg-success/20 text-success">
                    {completedExercises.length}/{condition.exercises.length} completed
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Progress value={completionPercentage} className="h-2" />
                <div className="space-y-3">
                  {condition.exercises.map((exercise, index) => {
                    const isCompleted = completedExercises.includes(exercise);
                    return (
                      <div 
                        key={index}
                        className={`flex items-center space-x-3 p-3 rounded-lg transition-all cursor-pointer ${
                          isCompleted 
                            ? 'bg-success/10 border border-success/20' 
                            : 'bg-muted/30 hover:bg-muted/50 border border-transparent'
                        }`}
                        onClick={() => handleExerciseComplete(exercise)}
                      >
                        {isCompleted ? (
                          <CheckCircle2 className="w-5 h-5 text-success flex-shrink-0" />
                        ) : (
                          <Circle className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                        )}
                        <span className={`flex-1 ${isCompleted ? 'text-success line-through' : 'text-foreground'}`}>
                          {exercise}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Mood Logging */}
            <Card className="bg-gradient-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  <span>Mood Check-In</span>
                </CardTitle>
                <CardDescription>How are you feeling today?</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Low</span>
                    <span className="font-medium">Current: {currentMood[0]}/10</span>
                    <span>High</span>
                  </div>
                  <Slider
                    value={currentMood}
                    onValueChange={setCurrentMood}
                    max={10}
                    min={1}
                    step={1}
                    className="w-full"
                  />
                </div>
                <Button onClick={handleMoodLog} className="w-full">
                  Log Mood
                </Button>
              </CardContent>
            </Card>

            {/* Progress Chart */}
            <Card className="bg-gradient-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="w-5 h-5 text-success" />
                  <span>Progress Overview</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <MoodChart entries={moodEntries} condition={condition.id} />
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="bg-gradient-card">
              <CardHeader>
                <CardTitle className="text-lg">Your Journey</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">{moodEntries.filter(e => e.condition === condition.id).length}</div>
                    <div className="text-sm text-muted-foreground">Mood Logs</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-success">{completedExercises.length}</div>
                    <div className="text-sm text-muted-foreground">Exercises Done</div>
                  </div>
                </div>
                <Separator />
                <div className="text-center">
                  <div className="text-2xl font-bold text-warning">{progress?.totalSessions || 0}</div>
                  <div className="text-sm text-muted-foreground">Total Sessions</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConditionPage;