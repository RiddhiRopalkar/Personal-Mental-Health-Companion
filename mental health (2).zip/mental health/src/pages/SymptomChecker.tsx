import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Brain, CheckCircle, AlertCircle } from 'lucide-react';
import { CONDITIONS } from '@/contexts/MentalHealthContext';

interface Question {
  id: string;
  text: string;
  conditions: string[];
  weight: number;
}

const SYMPTOM_QUESTIONS: Question[] = [
  {
    id: 'overwhelmed',
    text: 'I often feel overwhelmed by daily tasks and responsibilities',
    conditions: ['stress', 'anxiety', 'depression'],
    weight: 2
  },
  {
    id: 'sleep_difficulty',
    text: 'I have trouble falling asleep or staying asleep',
    conditions: ['insomnia', 'stress', 'anxiety', 'depression'],
    weight: 3
  },
  {
    id: 'focus_problems',
    text: 'I struggle to concentrate or stay focused on tasks',
    conditions: ['adhd', 'depression', 'anxiety', 'stress'],
    weight: 2
  },
  {
    id: 'repetitive_thoughts',
    text: 'I have repetitive thoughts or behaviors that are hard to control',
    conditions: ['ocd', 'anxiety'],
    weight: 3
  },
  {
    id: 'worry_excessive',
    text: 'I worry excessively about things that might go wrong',
    conditions: ['anxiety', 'stress'],
    weight: 2
  },
  {
    id: 'energy_low',
    text: 'I feel tired or low on energy most days',
    conditions: ['depression', 'insomnia', 'stress'],
    weight: 2
  },
  {
    id: 'organization_difficult',
    text: 'I find it very difficult to organize my tasks and belongings',
    conditions: ['adhd'],
    weight: 3
  },
  {
    id: 'social_withdraw',
    text: 'I tend to avoid social situations or withdraw from others',
    conditions: ['depression', 'anxiety'],
    weight: 2
  },
  {
    id: 'physical_symptoms',
    text: 'I experience physical symptoms like racing heart, sweating, or trembling',
    conditions: ['anxiety', 'stress'],
    weight: 2
  },
  {
    id: 'perfectionism',
    text: 'I feel the need to do things perfectly or repeatedly check my work',
    conditions: ['ocd', 'anxiety'],
    weight: 2
  },
  {
    id: 'mood_changes',
    text: 'My mood changes significantly throughout the day',
    conditions: ['depression', 'stress', 'adhd'],
    weight: 1
  },
  {
    id: 'sleep_schedule',
    text: 'My sleep schedule is very irregular',
    conditions: ['insomnia', 'adhd', 'depression'],
    weight: 2
  }
];

type AnswerValue = 0 | 1 | 2 | 3; // Never, Rarely, Sometimes, Often

const SymptomChecker: React.FC = () => {
  const navigate = useNavigate();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, AnswerValue>>({});
  const [showResults, setShowResults] = useState(false);
  const [results, setResults] = useState<Record<string, number>>({});

  const handleAnswer = (value: AnswerValue) => {
    const question = SYMPTOM_QUESTIONS[currentQuestion];
    const newAnswers = { ...answers, [question.id]: value };
    setAnswers(newAnswers);

    if (currentQuestion < SYMPTOM_QUESTIONS.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      calculateResults(newAnswers);
    }
  };

  const calculateResults = (finalAnswers: Record<string, AnswerValue>) => {
    const conditionScores: Record<string, number> = {};
    
    // Initialize scores
    Object.keys(CONDITIONS).forEach(condition => {
      conditionScores[condition] = 0;
    });

    // Calculate scores based on answers
    SYMPTOM_QUESTIONS.forEach(question => {
      const answer = finalAnswers[question.id] || 0;
      const score = answer * question.weight;
      
      question.conditions.forEach(condition => {
        if (conditionScores[condition] !== undefined) {
          conditionScores[condition] += score;
        }
      });
    });

    // Normalize scores to percentages
    const maxPossibleScore = SYMPTOM_QUESTIONS.reduce((total, q) => total + (q.weight * 3), 0);
    const normalizedScores: Record<string, number> = {};
    
    Object.entries(conditionScores).forEach(([condition, score]) => {
      const relevantQuestions = SYMPTOM_QUESTIONS.filter(q => q.conditions.includes(condition));
      const maxScore = relevantQuestions.reduce((total, q) => total + (q.weight * 3), 0);
      normalizedScores[condition] = Math.round((score / maxScore) * 100);
    });

    setResults(normalizedScores);
    setShowResults(true);
  };

  const resetChecker = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setShowResults(false);
    setResults({});
  };

  const getSeverityLevel = (score: number): { level: string; color: string; description: string } => {
    if (score < 25) return { level: 'Low', color: 'bg-green-500', description: 'Minimal symptoms' };
    if (score < 50) return { level: 'Mild', color: 'bg-yellow-500', description: 'Some symptoms present' };
    if (score < 75) return { level: 'Moderate', color: 'bg-orange-500', description: 'Notable symptoms' };
    return { level: 'High', color: 'bg-red-500', description: 'Significant symptoms' };
  };

  const progress = ((currentQuestion + 1) / SYMPTOM_QUESTIONS.length) * 100;

  if (showResults) {
    const sortedResults = Object.entries(results)
      .sort(([, a], [, b]) => b - a)
      .filter(([, score]) => score > 0);

    const highestScore = sortedResults[0]?.[1] || 0;
    const isHealthy = highestScore < 25;

    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5 p-4">
        <div className="container mx-auto max-w-4xl">
          <div className="flex items-center gap-4 mb-8">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/')}
              className="text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </div>

          <Card className="mb-8">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                {isHealthy ? (
                  <CheckCircle className="h-16 w-16 text-green-500" />
                ) : (
                  <Brain className="h-16 w-16 text-primary" />
                )}
              </div>
              <CardTitle className="text-2xl">
                {isHealthy ? 'You\'re Doing Well!' : 'Your Symptom Assessment Results'}
              </CardTitle>
              <CardDescription>
                {isHealthy 
                  ? 'Your responses suggest minimal mental health symptoms. Keep up the good work with self-care!'
                  : 'Based on your responses, here are areas you might want to focus on:'
                }
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!isHealthy && (
                <>
                  <div className="space-y-4 mb-6">
                    {sortedResults.slice(0, 3).map(([condition, score]) => {
                      if (score < 20) return null;
                      const conditionData = CONDITIONS[condition as keyof typeof CONDITIONS];
                      const severity = getSeverityLevel(score);
                      
                      return (
                        <div key={condition} className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-3">
                              <span className="text-2xl">{conditionData.emoji}</span>
                              <div>
                                <h3 className="font-semibold">{conditionData.name}</h3>
                                <p className="text-sm text-muted-foreground">{severity.description}</p>
                              </div>
                            </div>
                            <Badge variant="secondary" className={`${severity.color} text-white`}>
                              {severity.level} ({score}%)
                            </Badge>
                          </div>
                          <Progress value={score} className="h-2 mb-3" />
                          <p className="text-sm text-muted-foreground mb-3">
                            {conditionData.description}
                          </p>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => navigate(`/condition/${condition}`)}
                            className="w-full"
                          >
                            Explore {conditionData.name} Resources
                          </Button>
                        </div>
                      );
                    })}
                  </div>

                  <div className="bg-muted/50 rounded-lg p-4 mb-4">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="h-5 w-5 text-orange-500 mt-0.5" />
                      <div>
                        <h4 className="font-semibold text-sm mb-1">Important Note</h4>
                        <p className="text-sm text-muted-foreground">
                          This assessment is for informational purposes only and is not a substitute for professional mental health diagnosis or treatment. If you're experiencing significant distress, please consider speaking with a mental health professional.
                        </p>
                      </div>
                    </div>
                  </div>
                </>
              )}

              <div className="flex gap-3">
                <Button onClick={resetChecker} variant="outline" className="flex-1">
                  Take Assessment Again
                </Button>
                <Button onClick={() => navigate('/')} className="flex-1">
                  Explore Resources
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const question = SYMPTOM_QUESTIONS[currentQuestion];

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5 p-4">
      <div className="container mx-auto max-w-2xl">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/')}
            className="text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <Brain className="h-8 w-8 text-primary" />
                <div>
                  <CardTitle>Mental Health Symptom Checker</CardTitle>
                  <CardDescription>
                    Question {currentQuestion + 1} of {SYMPTOM_QUESTIONS.length}
                  </CardDescription>
                </div>
              </div>
            </div>
            <Progress value={progress} className="h-2" />
          </CardHeader>
          <CardContent>
            <div className="mb-8">
              <h3 className="text-lg font-semibold mb-4">{question.text}</h3>
              <p className="text-sm text-muted-foreground mb-6">
                How often do you experience this? Select the option that best describes your experience over the past two weeks.
              </p>
            </div>

            <div className="space-y-3">
              {[
                { value: 0 as AnswerValue, label: 'Never', description: 'This doesn\'t apply to me' },
                { value: 1 as AnswerValue, label: 'Rarely', description: 'Once or twice in the past two weeks' },
                { value: 2 as AnswerValue, label: 'Sometimes', description: 'Several times a week' },
                { value: 3 as AnswerValue, label: 'Often', description: 'Nearly every day' }
              ].map((option) => (
                <Button
                  key={option.value}
                  variant="outline"
                  className="w-full h-auto p-4 text-left justify-start hover:bg-primary/5"
                  onClick={() => handleAnswer(option.value)}
                >
                  <div>
                    <div className="font-semibold">{option.label}</div>
                    <div className="text-sm text-muted-foreground">{option.description}</div>
                  </div>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SymptomChecker;