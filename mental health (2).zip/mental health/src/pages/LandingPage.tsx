import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, Phone, Shield, Users, Stethoscope } from 'lucide-react';
import { CONDITIONS } from '@/contexts/MentalHealthContext';
import heroImage from '@/assets/hero-mental-health.jpg';

const LandingPage = () => {
  const navigate = useNavigate();
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-hero rounded-full flex items-center justify-center">
                <Heart className="w-4 h-4 text-white" />
              </div>
              <h1 className="text-xl font-bold text-foreground">MindCare</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="bg-success-light text-success">
                <Shield className="w-3 h-3 mr-1" />
                Anonymous & Safe
              </Badge>
              <Button 
                variant="outline" 
                size="sm"
                className="bg-destructive/10 text-destructive border-destructive/20 hover:bg-destructive hover:text-destructive-foreground"
              >
                <Phone className="w-4 h-4 mr-2" />
                Crisis Help
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero opacity-5"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-5xl font-bold text-foreground mb-6 leading-tight">
              Your Personal Mental Health
              <span className="text-transparent bg-gradient-hero bg-clip-text"> Companion</span>
            </h2>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Get personalized support, track your progress, and build resilience with evidence-based techniques tailored to your needs.
            </p>
            
            <div className="mb-8">
              <Button
                onClick={() => navigate('/symptom-checker')}
                size="lg"
                className="bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90 text-white shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <Stethoscope className="h-5 w-5 mr-2" />
                Take Symptom Assessment
              </Button>
            </div>
            
            <div className="flex items-center justify-center space-x-8 mb-12">
              <div className="flex items-center space-x-2 text-muted-foreground">
                <Users className="w-5 h-5 text-success" />
                <span>10k+ helped daily</span>
              </div>
              <div className="flex items-center space-x-2 text-muted-foreground">
                <Shield className="w-5 h-5 text-primary" />
                <span>Completely private</span>
              </div>
              <div className="flex items-center space-x-2 text-muted-foreground">
                <Heart className="w-5 h-5 text-destructive" />
                <span>Science-backed</span>
              </div>
            </div>

            <div className="relative w-full max-w-3xl mx-auto rounded-2xl overflow-hidden shadow-hover">
              <img 
                src={heroImage} 
                alt="Serene mental health support illustration" 
                className="w-full h-auto object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Conditions Grid */}
      <section className="py-16 bg-card/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-foreground mb-4">
              Choose Your Focus Area
            </h3>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Select the area where you'd like personalized support, tips, and progress tracking.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {Object.entries(CONDITIONS).map(([key, condition]) => (
              <Link key={key} to={`/condition/${condition.id}`}>
                <Card className={`h-full transition-all duration-300 hover:shadow-hover hover:-translate-y-1 cursor-pointer bg-gradient-card border-l-4`} style={{borderLeftColor: `hsl(var(--${condition.color}))`}}>
                  <CardHeader className="text-center pb-4">
                    <div className="text-4xl mb-3">{condition.emoji}</div>
                    <CardTitle className="text-xl text-foreground">{condition.name}</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <CardDescription className="text-base mb-4">
                      {condition.description}
                    </CardDescription>
                    <Button 
                      variant={condition.color as any}
                    >
                      Get Started
                    </Button>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-foreground mb-4">
              Everything You Need to Thrive
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-primary" />
              </div>
              <h4 className="text-lg font-semibold text-foreground mb-2">Personalized Tips</h4>
              <p className="text-muted-foreground">Evidence-based guidance tailored to your specific needs and goals.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-success" />
              </div>
              <h4 className="text-lg font-semibold text-foreground mb-2">Progress Tracking</h4>
              <p className="text-muted-foreground">Visual charts and insights to see your growth over time.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-warning/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-warning" />
              </div>
              <h4 className="text-lg font-semibold text-foreground mb-2">Daily Exercises</h4>
              <p className="text-muted-foreground">Practical activities to build resilience and healthy habits.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Phone className="w-8 h-8 text-destructive" />
              </div>
              <h4 className="text-lg font-semibold text-foreground mb-2">Crisis Support</h4>
              <p className="text-muted-foreground">Immediate access to professional help when you need it most.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t py-8">
        <div className="container mx-auto px-4">
          <div className="text-center text-muted-foreground">
            <p className="mb-2">
              <strong>Crisis Resources:</strong> National Suicide Prevention Lifeline: 988 | Crisis Text Line: Text HOME to 741741
            </p>
            <p className="text-sm">
              This app provides educational content and should not replace professional medical advice. 
              Please consult a healthcare provider for personalized treatment.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;