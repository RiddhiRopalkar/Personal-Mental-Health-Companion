import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Battery, Heart, Users, CheckCircle, Star } from 'lucide-react';
import { useMentalHealth } from '@/contexts/MentalHealthContext';

const DepressionSupport: React.FC<{ conditionId: string }> = ({ conditionId }) => {
  const { activityProgress, completeExercise } = useMentalHealth();
  const [energyLevel, setEnergyLevel] = useState([5]);
  const [socialConnections, setSocialConnections] = useState(0);

  const selfCareItems = [
    { id: 'shower', label: 'Take a shower', category: 'hygiene', completed: false },
    { id: 'meal', label: 'Eat a nutritious meal', category: 'nutrition', completed: false },
    { id: 'sunlight', label: 'Get some sunlight', category: 'physical', completed: true },
    { id: 'connect', label: 'Connect with someone', category: 'social', completed: false },
    { id: 'creative', label: 'Do something creative', category: 'mental', completed: false },
    { id: 'gratitude', label: 'Practice gratitude', category: 'emotional', completed: false },
  ];

  const completedCount = selfCareItems.filter(item => item.completed).length;
  const completionRate = (completedCount / selfCareItems.length) * 100;

  const hopeGoals = [
    'Make my bed',
    'Text a friend',
    'Take a walk outside',
    'Listen to favorite music',
    'Write in journal',
  ];

  const activityJournal = [
    { activity: 'Watched sunset', enjoyment: 7, energy: 6 },
    { activity: 'Called mom', enjoyment: 8, energy: 7 },
    { activity: 'Cooked dinner', enjoyment: 5, energy: 4 },
  ];

  return (
    <div className="space-y-6">
      {/* Energy Level Tracking */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Battery className="h-5 w-5 text-depression" />
            Energy Level Today
          </CardTitle>
          <CardDescription>
            How energized do you feel? Low energy is normal with depression.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Slider
              value={energyLevel}
              onValueChange={setEnergyLevel}
              max={10}
              min={1}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Completely drained (1)</span>
              <span className="font-semibold">Current: {energyLevel[0]}</span>
              <span>Fully energized (10)</span>
            </div>
            <Button 
              onClick={() => completeExercise(conditionId, 'Log energy level')}
              className="w-full"
            >
              Log Energy Level
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Self-Care Checklist */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-success" />
            Daily Self-Care Checklist
          </CardTitle>
          <CardDescription>
            Small acts of self-care can make a big difference. Every checkbox matters.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-medium">Progress Today</span>
              <Badge variant={completionRate > 50 ? 'default' : 'secondary'}>
                {completedCount}/{selfCareItems.length} completed
              </Badge>
            </div>
            <Progress value={completionRate} className="mb-4" />
            
            <div className="space-y-3">
              {selfCareItems.map((item) => (
                <div key={item.id} className="flex items-center space-x-2">
                  <Checkbox 
                    id={item.id}
                    checked={item.completed}
                    className="data-[state=checked]:bg-depression data-[state=checked]:border-depression"
                  />
                  <label htmlFor={item.id} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                    {item.label}
                  </label>
                  <Badge variant="outline" className="text-xs">
                    {item.category}
                  </Badge>
                </div>
              ))}
            </div>
            
            {completionRate > 70 && (
              <div className="bg-success/10 border border-success/20 rounded-lg p-3 mt-4">
                <p className="text-sm text-success font-medium">🌟 Great job on self-care today!</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Social Connection Tracker */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            Social Connections
          </CardTitle>
          <CardDescription>
            Connection with others can help lift your mood, even briefly.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">{socialConnections}</div>
              <p className="text-sm text-muted-foreground">connections today</p>
            </div>
            
            <div className="grid grid-cols-2 gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setSocialConnections(prev => prev + 1)}
              >
                Text/Call Friend
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setSocialConnections(prev => prev + 1)}
              >
                Family Check-in
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setSocialConnections(prev => prev + 1)}
              >
                Online Community
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setSocialConnections(prev => prev + 1)}
              >
                Neighbor/Colleague
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Hope & Goals */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="h-5 w-5 text-warning" />
            Small Wins & Hope
          </CardTitle>
          <CardDescription>
            Focus on tiny accomplishments. Progress is progress, no matter how small.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h4 className="font-medium mb-2">Today's Small Goals</h4>
              <div className="space-y-2">
                {hopeGoals.map((goal, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => completeExercise(conditionId, goal)}
                  >
                    {goal}
                  </Button>
                ))}
              </div>
            </div>
            
            <div className="bg-warning/10 border border-warning/20 rounded-lg p-3">
              <p className="text-sm">
                <strong>Remember:</strong> You don't have to feel motivated to take action. 
                Sometimes action comes first, and feelings follow.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Activity Enjoyment Scale */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Heart className="h-5 w-5 text-destructive" />
            Activity Enjoyment Journal
          </CardTitle>
          <CardDescription>
            Track what activities bring you joy, even small amounts.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {activityJournal.map((entry, index) => (
              <div key={index} className="border rounded-lg p-3">
                <div className="flex justify-between items-start mb-2">
                  <span className="font-medium">{entry.activity}</span>
                  <div className="flex gap-2">
                    <Badge variant="outline">Joy: {entry.enjoyment}/10</Badge>
                    <Badge variant="outline">Energy: {entry.energy}/10</Badge>
                  </div>
                </div>
              </div>
            ))}
            
            <Button variant="outline" className="w-full">
              + Add Today's Activity
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DepressionSupport;