import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { TrendingUp, Clock, Target, AlertTriangle } from 'lucide-react';
import { useMentalHealth } from '@/contexts/MentalHealthContext';

const StressTracker: React.FC<{ conditionId: string }> = ({ conditionId }) => {
  const { activityProgress, completeExercise } = useMentalHealth();
  const [stressLevel, setStressLevel] = useState([5]);
  const [triggerInput, setTriggerInput] = useState('');
  const [workHours, setWorkHours] = useState([8]);
  const [relaxationTime, setRelaxationTime] = useState([30]);

  const currentProgress = activityProgress[conditionId];
  const stressTriggers = currentProgress?.conditionData?.stressTriggers || [];
  const workLifeBalance = Math.max(0, 100 - (workHours[0] * 8)); // Simple calculation

  const addTrigger = () => {
    if (triggerInput.trim()) {
      // In a real app, this would update the context
      setTriggerInput('');
    }
  };

  const relaxationTechniques = [
    { name: 'Box Breathing', duration: '5 min', active: true },
    { name: 'Progressive Muscle Relaxation', duration: '15 min', active: false },
    { name: '5-4-3-2-1 Grounding', duration: '3 min', active: false },
    { name: 'Mindful Walking', duration: '10 min', active: false },
  ];

  return (
    <div className="space-y-6">
      {/* Current Stress Level */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-stress" />
            Current Stress Level
          </CardTitle>
          <CardDescription>
            How stressed are you feeling right now? (1 = Very calm, 10 = Extremely stressed)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Slider
              value={stressLevel}
              onValueChange={setStressLevel}
              max={10}
              min={1}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Very Calm (1)</span>
              <span className="font-semibold">Current: {stressLevel[0]}</span>
              <span>Extremely Stressed (10)</span>
            </div>
            <Button 
              onClick={() => completeExercise(conditionId, 'Log stress level')}
              className="w-full"
              variant={stressLevel[0] > 7 ? 'destructive' : 'default'}
            >
              Log Stress Level
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Stress Triggers */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-warning" />
            Stress Triggers
          </CardTitle>
          <CardDescription>
            Track what's causing your stress to identify patterns
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="What's stressing you? (e.g., work deadline, traffic)"
                value={triggerInput}
                onChange={(e) => setTriggerInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addTrigger()}
              />
              <Button onClick={addTrigger}>Add</Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {['Work deadline', 'Traffic', 'Financial concerns', 'Family issues'].map((trigger) => (
                <Badge key={trigger} variant="secondary" className="cursor-pointer hover:bg-stress/20">
                  {trigger}
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Work-Life Balance */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            Work-Life Balance
          </CardTitle>
          <CardDescription>
            Track your work hours to maintain healthy boundaries
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Work Hours Today</label>
              <Slider
                value={workHours}
                onValueChange={setWorkHours}
                max={16}
                min={0}
                step={0.5}
                className="w-full mt-2"
              />
              <div className="flex justify-between text-sm text-muted-foreground mt-1">
                <span>0 hours</span>
                <span>{workHours[0]} hours</span>
                <span>16 hours</span>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium">Work-Life Balance Score</label>
              <Progress value={workLifeBalance} className="mt-2" />
              <p className="text-sm text-muted-foreground mt-1">
                {workLifeBalance > 60 ? 'Good balance!' : workLifeBalance > 30 ? 'Could improve' : 'Needs attention'}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Relaxation Techniques */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-secondary" />
            Relaxation Techniques
          </CardTitle>
          <CardDescription>
            Quick stress relief techniques you can use anytime
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {relaxationTechniques.map((technique) => (
              <Button
                key={technique.name}
                variant="outline"
                className="h-auto p-4 text-left justify-start"
                onClick={() => completeExercise(conditionId, technique.name)}
              >
                <div>
                  <div className="font-semibold">{technique.name}</div>
                  <div className="text-sm text-muted-foreground">{technique.duration}</div>
                </div>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StressTracker;