import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Moon, Clock, Thermometer, Bed, AlertCircle } from 'lucide-react';
import { useMentalHealth } from '@/contexts/MentalHealthContext';

const SleepCenter: React.FC<{ conditionId: string }> = ({ conditionId }) => {
  const { activityProgress, completeExercise } = useMentalHealth();
  const [bedtime, setBedtime] = useState('22:30');
  const [wakeTime, setWakeTime] = useState('07:00');
  const [sleepQuality, setSleepQuality] = useState([6]);
  const [roomTemp, setRoomTemp] = useState([68]);

  const sleepHygieneItems = [
    { id: 'no-screens', label: 'No screens 1 hour before bed', category: 'technology', completed: false },
    { id: 'cool-room', label: 'Keep bedroom cool (65-68°F)', category: 'environment', completed: true },
    { id: 'blackout', label: 'Use blackout curtains', category: 'environment', completed: false },
    { id: 'no-caffeine', label: 'No caffeine after 2 PM', category: 'diet', completed: true },
    { id: 'routine', label: 'Follow bedtime routine', category: 'routine', completed: false },
    { id: 'comfortable', label: 'Comfortable mattress & pillows', category: 'comfort', completed: true },
  ];

  const completedHygiene = sleepHygieneItems.filter(item => item.completed).length;
  const hygieneScore = (completedHygiene / sleepHygieneItems.length) * 100;

  // Calculate sleep duration
  const bedDateTime = new Date(`2024-01-01 ${bedtime}`);
  const wakeDateTime = new Date(`2024-01-02 ${wakeTime}`);
  const sleepHours = (wakeDateTime.getTime() - bedDateTime.getTime()) / (1000 * 60 * 60);
  const sleepDuration = sleepHours > 0 ? sleepHours : sleepHours + 24;

  const sleepDebt = Math.max(0, (8 - sleepDuration) * 7); // Weekly sleep debt

  const sleepEnvironmentFactors = [
    { factor: 'Room Temperature', value: roomTemp[0], optimal: '65-68°F', status: roomTemp[0] >= 65 && roomTemp[0] <= 68 ? 'good' : 'needs-attention' },
    { factor: 'Darkness Level', value: 85, optimal: '90%+', status: 'needs-attention' },
    { factor: 'Noise Level', value: 92, optimal: '90%+', status: 'good' },
    { factor: 'Comfort Level', value: 88, optimal: '85%+', status: 'good' },
  ];

  return (
    <div className="space-y-6">
      {/* Sleep Schedule Tracker */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-insomnia" />
            Sleep Schedule
          </CardTitle>
          <CardDescription>
            Consistency is key to better sleep. Track your bedtime and wake time.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Bedtime</label>
                <Input
                  type="time"
                  value={bedtime}
                  onChange={(e) => setBedtime(e.target.value)}
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Wake Time</label>
                <Input
                  type="time"
                  value={wakeTime}
                  onChange={(e) => setWakeTime(e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>
            
            <div className="bg-card border rounded-lg p-4">
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-insomnia">{sleepDuration.toFixed(1)}h</div>
                  <p className="text-sm text-muted-foreground">Sleep Duration</p>
                </div>
                <div>
                  <div className="text-2xl font-bold text-destructive">{sleepDebt.toFixed(1)}h</div>
                  <p className="text-sm text-muted-foreground">Weekly Sleep Debt</p>
                </div>
              </div>
            </div>

            <Button 
              onClick={() => completeExercise(conditionId, 'Log sleep schedule')}
              className="w-full"
            >
              Log Tonight's Schedule
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Sleep Quality Tracker */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bed className="h-5 w-5 text-primary" />
            Sleep Quality
          </CardTitle>
          <CardDescription>
            How well did you sleep last night?
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Slider
              value={sleepQuality}
              onValueChange={setSleepQuality}
              max={10}
              min={1}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Terrible (1)</span>
              <span className="font-semibold">Quality: {sleepQuality[0]}/10</span>
              <span>Excellent (10)</span>
            </div>
            
            <div className="grid grid-cols-3 gap-2 text-center">
              <Button variant="outline" size="sm">
                Restless
              </Button>
              <Button variant="outline" size="sm">
                Woke Often
              </Button>
              <Button variant="outline" size="sm">
                Deep Sleep
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sleep Hygiene Checklist */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Moon className="h-5 w-5 text-secondary" />
            Sleep Hygiene Checklist
          </CardTitle>
          <CardDescription>
            Good sleep habits that improve your sleep quality over time.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-medium">Sleep Hygiene Score</span>
              <Badge variant={hygieneScore > 60 ? 'default' : 'secondary'}>
                {completedHygiene}/{sleepHygieneItems.length} completed
              </Badge>
            </div>
            <Progress value={hygieneScore} className="mb-4" />
            
            <div className="space-y-3">
              {sleepHygieneItems.map((item) => (
                <div key={item.id} className="flex items-center space-x-2">
                  <Checkbox 
                    id={item.id}
                    checked={item.completed}
                    className="data-[state=checked]:bg-insomnia data-[state=checked]:border-insomnia"
                  />
                  <label htmlFor={item.id} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex-1">
                    {item.label}
                  </label>
                  <Badge variant="outline" className="text-xs">
                    {item.category}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sleep Environment Optimizer */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Thermometer className="h-5 w-5 text-warning" />
            Sleep Environment
          </CardTitle>
          <CardDescription>
            Optimize your bedroom for better sleep quality.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Room Temperature (°F)</label>
              <Slider
                value={roomTemp}
                onValueChange={setRoomTemp}
                max={80}
                min={60}
                step={1}
                className="w-full mt-2"
              />
              <div className="flex justify-between text-sm text-muted-foreground mt-1">
                <span>60°F</span>
                <span>{roomTemp[0]}°F {roomTemp[0] >= 65 && roomTemp[0] <= 68 ? '✓' : '⚠️'}</span>
                <span>80°F</span>
              </div>
            </div>

            <div className="space-y-3">
              {sleepEnvironmentFactors.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <div className="font-medium">{item.factor}</div>
                    <div className="text-sm text-muted-foreground">Optimal: {item.optimal}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={item.status === 'good' ? 'default' : 'secondary'}>
                      {typeof item.value === 'number' && item.factor !== 'Room Temperature' ? `${item.value}%` : `${item.value}${item.factor === 'Room Temperature' ? '°F' : ''}`}
                    </Badge>
                    {item.status === 'good' ? (
                      <div className="text-success">✓</div>
                    ) : (
                      <AlertCircle className="h-4 w-4 text-warning" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sleep Debt Calculator */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-destructive" />
            Sleep Debt Analysis
          </CardTitle>
          <CardDescription>
            Track accumulated sleep loss and recovery strategies.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-center">
              <div className="border rounded-lg p-4">
                <div className="text-xl font-bold text-destructive">{sleepDebt.toFixed(1)}h</div>
                <p className="text-sm text-muted-foreground">Weekly Debt</p>
              </div>
              <div className="border rounded-lg p-4">
                <div className="text-xl font-bold text-primary">2.3h</div>
                <p className="text-sm text-muted-foreground">To Recover</p>
              </div>
            </div>

            <div className="bg-muted/50 rounded-lg p-4">
              <h4 className="font-medium mb-2">Recovery Tips</h4>
              <ul className="text-sm space-y-1">
                <li>• Go to bed 30 minutes earlier for the next week</li>
                <li>• Avoid naps longer than 20 minutes</li>
                <li>• Maintain consistent sleep schedule on weekends</li>
                <li>• Prioritize sleep quality over quantity recovery</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SleepCenter;